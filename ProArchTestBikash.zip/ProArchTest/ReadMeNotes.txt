I dont have MS office in my device. So I have hard coded the values in memory.
Also written the code to read data from csv file but wont work unless MS Excel is there in the system.
2 Actions: To get the match Details and player details from the match are there. 
Constructor dependency injection is used in the .net core app.