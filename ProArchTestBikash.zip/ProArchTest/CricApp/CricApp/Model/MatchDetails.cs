﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CricApp.Model
{
    public class MatchDetails
    {
        public int MatchNo { get; set; }
        public string MatchVenue { get; set; }
        public string Season { get; set; }
        public DateTime StartDate { get; set; }
    }
}
